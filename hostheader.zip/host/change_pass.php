<?php
require_once 'config/database.php';
session_start();
$errors = [];

if(!isset($_GET['token']) || !$_GET['token']){
    die();
}
$token = $_GET['token'];
$now =  date("Y-m-d H:i:s");
$stm = $connect->prepare("SELECT * FROM passwordreset WHERE token= ? and expire_at >'$now'");
$stm->bind_param("s",$token);
$stm->execute();
$result = $stm->get_result();
if(!$result->num_rows){
    die("Token Not Valid");
}
if($_SERVER['REQUEST_METHOD']=='POST'){





    $password = mysqli_real_escape_string($connect,$_POST['password']);
    $password_confirm = mysqli_real_escape_string($connect,$_POST['passowrd_confirm']);
    if(empty($password)){array_push($errors,"Password is required");}
    if(empty($password_confirm)){array_push($errors,"Password-Confirm is required");}
    if($password != $password_confirm){array_push($errors,"Password Not match");}
    if(!count($errors)){
        $user_id = $result->fetch_assoc()['user_id'];
        $hash_password=password_hash($password,PASSWORD_DEFAULT);
        $connect->query("update users set password='$hash_password' where id='$user_id'");
        $connect->query("delete from passwordreset where userId='$user_id'");
        if($connect->error){
            echo "Error";
        }
        header("location:signin.php");

    }






}
?>


<!DOCTYBE html>
<html>
<head>
    <link rel="stylesheet" href="style/login.css">
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <title>Login</title>
    <link rel="shortcut icon" href="Icon/logo.png">
</head>

<body>

</div>
<div class="login">
    
    <form action="" method="post" >
        <input type="text" name="email" placeholder="كلمة المرور الجديدة" title="username" />
        <input type="password" name="password" placeholder="اعادة كلمة المرور الجديدة" title="password" />
        <button title="login">استعادة</button>
    </form>
</div>
</body>
</html>
