<?php
if($_SERVER['HTTP_HOST'] != "localhost"){
    echo "لايوجد لديك صلاحية للوصل";
    die();
}

?>
<script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" data-auto-replace-svg="nest"></script>
<script src="js/admin.js"></script>
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js'></script>
<script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" data-auto-replace-svg="nest"></script>
<link rel="stylesheet" href="style/admin.css">
<div id='admin' class='main'>
    <h1><span id='which_view'>ADMIN DASHBOARD</span><input type='checkbox' id='view' style='display:none;'>
        <label for="view" style='background-image:url("https://www.pngfind.com/pngs/m/212-2129306_change-icon-png-shake-hand-circle-icon-transparent.png");background-repeat: no-repeat;background-size:cover;background-position: center; height:40px;width:40px;display:inline-block; cursor:pointer;' /> </h1>
    <ul class="tabs">
        <li class="tab-link " data-tab="tab-1"><i class="fas fa-home"></i> MAIN</li>
        <li class='tab-link current' data-tab='tab-2'><i class="fas fa-paw"></i> DOGS</li>
        <li class="tab-link admin" data-tab="tab-3"><i class="fas fa-address-book"></i> FOSTERS</li>
        <li class='tab-link' data-tab='tab-4'><i class="fas fa-folder-open"></i> ADOPTABLES</li>
        <li class='tab-link' data-tab='tab-5'><i class="fas fa-user-circle"></i> PROFILE</li>
    </ul>

    <div id="tab-1" class="tab-content ">
        dashboard w/ calendar (all upcoming vet appointments, adoption events, transports), basic summary of sections below</div>

    <div id='tab-2' class='tab-content current'>
        <div id='foster_view' class='hidden fosters'>
            <div class="popup-container" id="Listpopup">
                <div class="popup">
                    <button class="popup-close popup-close-btn">x</button>
                </div>
            </div>
        </div>
        <div class='sideMenu admin'>
            <ul class='menu admin'>
                <li>Main</li>
                <li>On Hold</li>
                <li>Incoming</li>
                <li>View All</li>
            </ul>
        </div>
        <div id='rescue_main' class='content main'>

            <div class="row admin">
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-success">
                        <i class="fas fa-clinic-medical"></i>
                        <span class="heading">Pending Medical</span>
                        <span class="value"><span id='med_hold'></span></span>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-primary">
                        <i class="fas fa-car-side"></i>
                        <span class="heading">Incoming</span>
                        <span class="value"><span id='transport'></span></span>
                    </div>
                </div>
            </div>
        </div>
        <div id='rescue_hold' class='hidden main'>
            <table id='current' class='admin'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Added</th>
                    <th>Hold Reason</th>
                    <th>Appt Date?</th>
                    <th>Foster</th>
                </tr>
                </thead>
                <tr>
                    <td>Daisy</td>
                    <td>3/1/2020</td>
                    <td>Malnourished</td>
                    <td>NA</td>
                    <td></td>
                </tr>
                <tr>
                    <td>Holden</td>
                    <td>5/22/2020</td>
                    <td>Spay/Neuter</td>
                    <td>5/31/2020</td>
                    <td>
                    </td>
                </tr>
            </table>
        </div>
        <div id='rescue_incoming' class='hidden main'>

            <table id='incoming' class='admin'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Breed</th>
                    <th>Gender</th>
                    <th>Size</th>
                    <th>Age</th>
                    <th>Dogs</th>
                    <th>Kids</th>
                    <th>Arrival Date</th>
                    <th>Foster?</th>
                </tr>
                </thead>
            </table>

        </div>
        <div id='rescue_all' class='hidden main'>
            <table id='rescue_full'>

            </table>

        </div>
    </div>

    <div id='tab-3' class='tab-content'>
        <div class='sideMenu admin'>
            <ul class='menu admin'>
                <li>Main</li>
                <li>Current</li>
                <li>Applications</li>
                <li>View All</li>
            </ul>
        </div>
        <div id='fosters_main' class='main content'>
            <div class="row admin">
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-success">
                        <i class="fas fa-sun"></i>
                        <span class="heading">Approved: Active</span>
                        <span class="value"><span id='activeN'></span></span>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-success">
                        <i class="fas fa-moon"></i>
                        <span class="heading">Approved: Inactive</span>
                        <span class="value"><span id='inactiveN'></span></span>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-primary">
                        <i class="fas fa-cloud"></i>
                        <span class="heading">Total Applications</span>
                        <span class="value"><span id='fosterApps'></span></span>
                    </div>
                </div>
            </div>
        </div>
        <div id='fosters_active' class='main hidden'>
            <table id='fosters'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Approved</th>
                    <th>Active?</th>
                    <th>Current Fosters</th>
                    <th>Past Fosters</th>
                    <th>Supplies Loaned</th>
                    <th>Review Date</th>
                </tr>
                </thead>
                <tr>
                    <td>Melie Lewis</td>
                    <td>3/27/2020</td>
                    <td class='status-success'>Yes</td>
                    <td>1</td>
                    <td>4</td>
                    <td>1 Lg Kennel</td>
                    <td>3/27/2021</td>
                </tr>
            </table>
            <table id='inactive' style='display:none;'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Approved</th>
                    <th>Active?</th>
                    <th>Current Fosters</th>
                    <th>Past Fosters</th>
                    <th>Supplies Loaned</th>
                    <th>Review Date</th>
                </tr>
                </thead>
                <tr>
                    <td></td>
                    <td>11/13/2019</td>
                    <td class='status-error'>No</td>
                    <td>0</td>
                    <td>2</td>
                    <td>1 Sm Kennel</td>
                    <td>11/13/2020</td>
                </tr>
            </table>
            <div class="popup-container" id="popup">
                <div class="popup">
                    <button class="popup-close popup-close-btn" id='close'>x</button>
                </div>
            </div>
            1. preferences (app options: first q. [1. single adult 2. single puppy 3. multiple (adults or puppies) 4. medical or rehab dog 5. nursing or pregnant dog 6. weaned litter], energy level 1 [1. mellow - coach potato 2. active - short walks dog park play 3. energetic - running buddy])
            2. living situation (pets, children, home type, rent or own, able to quarantine)
            3. date added-date needs review
            4.foster history (automate summary of what types they've fostered, offered to take to identify likely preferences for generating match suggestions)
            5. items loaned
        </div>
        <div id='fosters_app' class='main hidden'>
            <table id='applied_fosters'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Applied</th>
                    <th>References Contacted</th>
                    <th>Home Inspection</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tr>
                    <td>Jane Doe</td>
                    <td>5/24/2020</td>
                    <td>0/2</td>
                    <td>Incomplete</td>
                    <td>Pending</td>
                </tr>
            </table>
        </div>
        <div id='fosters_full' class='main hidden'>
            <table id='fosters_all'>
            </table>
        </div>
    </div>

    <div id='tab-4' class='tab-content'>
        <div id='foster_dogs' class='hidden fosters'>

        </div>
        <div class='sideMenu admin'>
            <ul class='menu admin'>
                <li>Main</li>
                <li>Available</li>
                <li>Pending/Adopted</li>
                <li>View All</li>
            </ul>
        </div>
        <div id='adoption_main' class='content main'>
            <div class="row admin">
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-success">
                        <i class="fas fa-paw"></i>
                        <span class="heading">Available</span>
                        <span class="value"><span id='availableDogs'></span></span>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-success">
                        <i class="fas fa-dog"></i>
                        <span class="heading">Pending</span>
                        <span class="value"><span id='pendingApps'></span></span>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">
                    <div class="rad-info-box rad-txt-primary">
                        <i class="fas fa-heart"></i>
                        <span class="heading">Adopted</span>
                        <span class="value"><span id='pastDogs'></span></span>
                    </div>
                </div>
            </div>

        </div>
        <div id='fosterAdopt_view' class='hidden fosters'>

        </div>
        <div id='adoption_available' class='hidden main'>
            <table id='available'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Added</th>
                    <th>Foster</th>
                    <th>Applications</th>
                    <th>Petstablished</th>
                    <th>Petfinder</th>
                </tr>
                </thead>
            </table>
            <table id='pendingAdoption' style='display:none;'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Added</th>
                    <th>Foster</th>
                    <th>Applications</th>
                    <th>Petstablished</th>
                    <th>Petfinder</th>
                </tr>
                </thead>
            </table>
        </div>
        <div id='adoption_historic' class='hidden main'>
            <table id='adopted'>
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Date Added</th>
                    <th>Date Adopted</th>
                    <th>Foster</th>
                    <th>Adopted By</th>
                </tr>
                </thead>
            </table>
        </div>
        <div id='all_dogs' class='hidden main'>
            <table id='allDogs'>
            </table>
        </div>
    </div>
    <div id='tab-5' class='tab-content'>
        <div class='sideMenu'>
            <ul class='menu'>
                <li>Main</li>
                <li>Preferences</li>
                <li>History</li>
            </ul>
        </div>
        <div id='profile_main' style='text-align:right;'>
            <i class="fas fa-edit" style='font-size:25px;cursor:pointer;'></i></div><br>
        <div class='contactInfo'>
        </div>
    </div>
</div>