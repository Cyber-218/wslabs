<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '/opt/lampp/htdocs/libphp-phpmailer/src/PHPMailer.php';
require '/opt/lampp/htdocs/libphp-phpmailer/src/SMTP.php';
require '/opt/lampp/htdocs/libphp-phpmailer/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



$connect = new mysqli("localhost","root","","host");
$err= [];
$config['app_url'] = "tot.com";
if(isset($_SESSION['logged_in'])){
    header("location:index.php");
    die();
}
if($_SERVER['REQUEST_METHOD']=='POST'){


    $emailRegister = trim(strtolower($_POST['email']));


    $email = mysqli_real_escape_string($connect,htmlspecialchars($emailRegister));
    if(empty($email)){array_push($err,"Email or Username is require");}


    if(!count($err)){
        $userExists = $connect->query("select id,email,username from users where email='$email' or username='$email' limit 1");
        if($userExists->num_rows){
            $userExists = $userExists->fetch_assoc();
            if(strpos($email,"@") !== False){
                $userId = $userExists['id'];
                $username = $userExists['username'];
                $connect->query("delete from passwordreset where user_id='$userId'");
                $token = bin2hex(random_bytes(33));
                $expire_at = date("Y-m-d H:i:s",strtotime("+1 day"));
                $connect->query("insert into passwordreset(userId,token,expire_at)values('$userId','$token','$expire_at')");
            }else{
                $email = $userExists['email'];
                $userId = $userExists['id'];
                $username = $userExists['username'];
                $connect->query("delete from passwordreset where user_id='$userId'");
                $token = bin2hex(random_bytes(33));
                $expire_at = date("Y-m-d H:i:s",strtotime("+1 day"));
                $connect->query("insert into passwordreset(userId,token,expire_at)values($userId,'$token','$expire_at')");
 
            }

            $mail = new PHPMailer(true);
            try {

                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp-mail.outlook.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'test1233@outlook.sa';                     //SMTP username
                $mail->Password   = 'AbcdEfg123AqDA2211213!@@!#';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
                $mail->Port       = 587;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

                //Recipients
                $Password_rest_url = "http://" . $config['app_url']."/host/change_pass.php?token=" . $token;
                $mail->setFrom('test1233@outlook.sa');
                $mail->addAddress('test1233@outlook.sa');     //Add a recipient
                $mail->Subject = 'Here is the subject';
                $mail->Body    = '<a href="'.$Password_rest_url.'">reset</a>';
                $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                $mail->send();
                echo 'Message has been sent';
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
    }


}





?>

<link rel="stylesheet" href="style/login.css">
<body>
<?php
if(count($err)){
    foreach ($err as $er){
        echo $er;
    }
}


?>
<div class="login">
    <h1>استعادة كلمة المرور</h1>
    <form action="" method="post" >
        <input type="text" name="email" placeholder="البريد الالكتروني او اسم المستخدم" title="username" />
        <button title="login">استعادة</button>
    </form>
</div>
</body>
