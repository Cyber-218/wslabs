<?php
require 'config/database.php';
$err = [];
if($_SERVER['REQUEST_METHOD'] == "POST"){
    $username = mysqli_real_escape_string($connect,htmlspecialchars($_POST['username']));
    $email = mysqli_real_escape_string($connect,htmlspecialchars($_POST['email']));
    $pass = mysqli_real_escape_string($connect,htmlspecialchars($_POST['password']));
    if(empty($username)){
        array_push($err,"اسم المستخدم مطلوب");
    }
    if(empty($email)){
        array_push($err,"البريد الالكتروني مطلوب");
    }
    if(empty($pass)){
        array_push($err,"كلمة المرور مطلوبة");
    }
    if(!count($err)){
        $checkEmail = $connect->query("select * from users where email='$email'");
        if($checkEmail->num_rows){
            array_push($err,"البريد الالكتروني مستخدم من قبل");
        }
        $checkUsername = $connect->query("select * from users where username='$username'");
        if($checkUsername->num_rows){
            array_push($checkUsername,"اسم المستخدم مستخدم");
        }
    }
    if(!count($err)){
        $registerSuccess = "تم الستجيل بنجاح";
        $connect->query("insert into users(username,email,password) values('$username','$email','$pass')");

        ?>
        <script>
           setInterval(function(){ location.href='login.php' }, 2000);

        </script>
<?php
    }

}

?>

<link rel="stylesheet" href="style/login.css">
<body>
<center>
<?php if(count($err)){
    foreach ($err as $er){
        echo  $er . "<br>";
    }
} ?>
<?php
if(isset($registerSuccess)){
    echo $registerSuccess;
}

?>
</center>

<div class="container">
    <div class="login">
        <h1>تسجيل</h1>
        <form action="" method="post" >
            <input type="text" name="username" placeholder=" اسم المستخدم" title="username" />
            <input type="text" name="email" placeholder="البريد الالكتروني او اسم المستخدم" title="username" />
            <input type="password" name="password" placeholder="كلمة المرور" title="password" />
            <a style="color: white" href="login.php"> لديك حساب؟</a><br>
            <button title="login">تسجيل </button>
        </form>
    </div>
</body>
