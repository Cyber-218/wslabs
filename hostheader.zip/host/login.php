<?php
session_start();
require_once 'config/database.php';
if($_SERVER['REQUEST_METHOD']=="POST"){
    $email = mysqli_real_escape_string($connect,htmlspecialchars($_POST['email']));
    $pass = mysqli_real_escape_string($connect,htmlspecialchars($_POST['password']));
    if(strpos($email,'@')){
        $valid = $connect->query("select * from users where email='$email' and password='$pass' ");
        if($valid->num_rows){
            $_SESSION['logged'] = true;
            echo "<script>location.href='index.php'</script>";
        }else{
            echo "البريد الالكتروني او كلمة المرور خاطئه";
        }

    }else{
        $valid = $connect->query("select * from users where username='$email' and password='$pass' ");
        if($valid->num_rows){
            $_SESSION['logged'] = true;
            echo "<script>location.href='index.php'</script>";
        }else{
            echo "البريد الالكتروني او كلمة المرور خاطئه";
        }
    }
}

?>


<link rel="stylesheet" href="style/login.css">
<body>
<div class="login">
    <h1>تسجيل الدخول</h1>
    <form action="" method="post" >
        <input type="text" name="email" placeholder="البريد الالكتروني او اسم المستخدم" title="username" />
        <input type="password" name="password" placeholder="كلمة المرور" title="password" />
        <a  style="color: white" href="password_reset.php">نسيت كلمة المرور؟</a><br>
        <a style="color: white" href="register.php">ليس لديك حساب؟</a><br>
        <button title="login">تسجيل دخول</button>
    </form>
</div>

</body>