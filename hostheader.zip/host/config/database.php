<?php
$connect = new mysqli("localhost","root","","host");
