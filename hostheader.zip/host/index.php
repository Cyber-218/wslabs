<?php
session_start();

?>
<link rel="stylesheet" href="style/index.css">
<div class="header">
    <div class="nav-menu">
        <div class="logo">StoneWork</div>
        <div class="menu">
            <ul>
                <?php if(isset($_SESSION['logged'])){ ?>
                <li><a href="logout.php">تسجيل خروج</a></li>
                <?php }else{ ?>
                <li><a href="login.php">تسجيل دخول</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
    <div class="banner">
        <h1>StoneWork</h1>
    </div>
</div>
<div class="container">
    <div class="text">
        <h1>Fusce ultrices fringilla metus</h1>
        <p>Donec leo, vivamus fermentum nibh in augue praesent a lacus at urna congue</p>
    </div>
    <div class="main">
        <div class="single">
            <i class="fas fa-cloud-download-alt"></i>
            <p>Praesent pellentesque facilisis elit. Class aptent taciti sociosqu ad torquent per conubia nostra.</p>
            <a href="index.html">More info</a>
        </div>
        <div class="single">
            <i class="fas fa-cogs"></i>
            <p>Etiam neque. Vivamus consequat lorem at nisl. Nullam wisi a sem semper eleifend. Donec mattis.</p>
            <a href="index.html">More info</a>
        </div>
        <div class="single">
            <i class="fas fa-wrench"></i>
            <p>Aenean lectus lorem, imperdiet at, ultrices eget, ornare et, wisi. Pellentesque adipiscing purus.</p>
            <a href="index.html">More info</a>
        </div>
    </div>
    <footer>
        <h1>Fusce ultrices fringilla metus</h1>
        <p>Donec leo, vivamus fermentum nibh in augue praesent a lacus at urna congue </p>

        <p class="txt">This is <b>StoneWork</b> , a free, fully standards-compliant CSS template designed by TEMPLATED. The photos in this template are from Fotogrph. This free template is released under the Creative Commons Attribution license, so you're pretty much free
            to do whatever you want with it (even use it commercially) provided you give us credit for it. Have fun :)</p>


        <a href="#">Etiam prousere</a>

        <span> &copy; Website design by <b>Leyla</b>  | 12.02.2021</span>
    </footer>
</div>